package eu.glowacki.utp.assignment10.repositories.test;

import eu.glowacki.utp.assignment10.UnimplementedException;
import eu.glowacki.utp.assignment10.dtos.GroupDTO;
import eu.glowacki.utp.assignment10.repositories.IGroupRepository;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;


public class GroupRepositoryTest extends RepositoryTestBase<GroupDTO, IGroupRepository> {

    protected IGroupRepository getRepositoryFromPersistenceContext() {
        IGroupRepository repository = getContext().getGroupRepository();
        return repository;
    }

    @Test
    public void add() {
        IGroupRepository repository = getRepository();
        int count = repository.getCount();
        GroupDTO group = new GroupDTO(0, "groupname-1", "groupname-1 description");
        repository.add(group);
        int expectedCount = count + 1;
        int actualCount = repository.getCount();
        Assert.assertEquals(expectedCount, actualCount);
    }

    @Test
    public void update() {
    	IGroupRepository repository = getRepository();
    	final String originalName = "original groupname-1";
    	GroupDTO group = new GroupDTO(0,originalName,"original groupname-1 description");
    	repository.add(group);
		List<GroupDTO> fetchedOriginalList = repository.findByName(originalName);
		Assert.assertNotNull(fetchedOriginalList);
		Assert.assertEquals(1,fetchedOriginalList.size());
		GroupDTO fetchedOriginal = fetchedOriginalList.get(0);
		Assert.assertNotNull(fetchedOriginal);
		Assert.assertEquals(originalName,fetchedOriginal.getName());

    }

    @Test
    public void addOrUpdate() {
    }

    @Test
    public void delete() {
    }

    @Test
    public void findById() {
    }

    @Test
    public void findByName() {
    }

    @Override
    protected IGroupRepository Create() {
        throw new UnimplementedException("eee");
    }



	}
