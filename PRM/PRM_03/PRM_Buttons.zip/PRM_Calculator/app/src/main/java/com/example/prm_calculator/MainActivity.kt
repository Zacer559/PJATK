package com.example.prm_calculator

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }


    fun onNews(view: View) {
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.onet.pl"))
        startActivity(browserIntent)
    }

    fun onImageView(view: View) {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivity(Intent.createChooser(intent, "Select Picture"))
        }


    fun onPDF(view: View) {
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.pzu.pl/_fileserver/item/1523141"))
        startActivity(browserIntent)
        }
    }



